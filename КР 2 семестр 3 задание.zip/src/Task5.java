import java.util.Scanner;

public class Task5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите числа через пробел:");
        String[] input = scanner.nextLine().split(" ");
        int sum = 0;
        for (String num : input) {
            sum += Integer.parseInt(num);
        }
        System.out.println("Сумма: " + sum);
    }
}