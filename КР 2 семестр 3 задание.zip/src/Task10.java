public class Task10 {
    public static void main(String[] args) {
        boolean x = true;
        boolean result = !((x || x) == true && ((x || x) == true));
        System.out.println(result); // false
    }
}