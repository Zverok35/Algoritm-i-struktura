public class Task4 {
    public static int strCount(String str, char ch) {
        int count = 0;
        for (char c : str.toCharArray()) {
            if (c == ch) count++;
        }
        return count;
    }

    public static void main(String[] args) {
        System.out.println(strCount("Hello", 'o')); // 1
        System.out.println(strCount("Hello", 'l')); // 2
        System.out.println(strCount("", 'z'));      // 0
    }
}