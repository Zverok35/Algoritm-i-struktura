import java.util.Scanner;

public class Task3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите строку: ");
        String input = scanner.nextLine();
        String upper = input.toUpperCase();
        System.out.println("В верхнем регистре: " + upper);
    }
}