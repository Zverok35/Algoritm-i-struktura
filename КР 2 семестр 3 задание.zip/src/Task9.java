import java.util.Scanner;

public class Task9 {
    public static boolean endsWith(String a, String b) {
        return b.endsWith(a);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите первую строку: ");
        String a = scanner.next();
        System.out.print("Введите вторую строку: ");
        String b = scanner.next();
        System.out.println("Оканчивается ли вторая строка на первую? " + endsWith(a, b));
    }
}