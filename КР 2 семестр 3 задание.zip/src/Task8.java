import java.util.Scanner;

public class Task8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите три стороны треугольника: ");
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();

        if (a + b > c && a + c > b && b + c > a) {
            System.out.println("Можно построить треугольник.");
            double angleA = Math.acos((b*b + c*c - a*a) / (2 * b * c));
            double angleB = Math.acos((a*a + c*c - b*b) / (2 * a * c));
            double angleC = Math.acos((a*a + b*b - c*c) / (2 * a * b));
            double maxAngle = Math.toDegrees(Math.max(angleA, Math.max(angleB, angleC)));
            System.out.printf("Наибольший угол: %.2f градусов%n", maxAngle);
        } else {
            System.out.println("Нельзя построить треугольник.");
        }
    }
}